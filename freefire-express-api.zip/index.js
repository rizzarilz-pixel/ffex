const FreeFireAPI = require('./lib/api');

module.exports = FreeFireAPI;
